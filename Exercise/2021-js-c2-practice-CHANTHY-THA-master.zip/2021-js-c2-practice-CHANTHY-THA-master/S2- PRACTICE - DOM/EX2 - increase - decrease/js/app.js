const MIN = 100;
// FUNCIONS --------------------------------------------------
let decreaseBox = () => {
	
	if (number > 100 ){
		number -= 300;
		document.getElementById("box").style.width = number + "px";
	}
};

let increaseBox = () => {
	if (number < 1000){
		number += 300;
		document.getElementById("box").style.width = number + "px";
	}
};

let number = MIN;
// MAIN --------------------------------------------------
let box = document.querySelector("#box");

let btnDecrease = document.querySelector("#btn-decrease-width");
btnDecrease.addEventListener("click", decreaseBox);

let btnIncrease = document.querySelector("#btn-increase-width");
btnIncrease.addEventListener("click", increaseBox);

