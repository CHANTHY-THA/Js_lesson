// 1- Get the list of books ( tips : use the querySelectorAll )
// TODO
let num = document.getElementsByClassName('book-name').length;

// 2- Display the number of books on paragrah "books-number"
// TODO
document.getElementById('books-number').textContent = num ;

// 3- Display the title of the books  on paragrah "books-titles"
// TODO
let titleOfbook = '';
for(i = 0; i < num ; i++){
    titleOfbook += document.getElementsByClassName('book-name')[i].textContent;
    if(i < num - 1){
        titleOfbook += '  ,  '
    }
    document.getElementById('books-titles').textContent = titleOfbook;
}