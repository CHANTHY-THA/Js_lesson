

// CONSTANT

let text = document.getElementById('textFieldId1').value;
text = text.value.toUpperCase();
console.log(text)
// uppercase 

// lowercase