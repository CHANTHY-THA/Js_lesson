

let showImage = () => {
    document.getElementsByClassName('card')[0].style.display = 'block';
    document.getElementsByClassName('card')[1].style.display = 'block';
 }
 let hideImage = () => {
     document.getElementsByClassName('card')[0].style.display = 'none';
     document.getElementsByClassName('card')[1].style.display = 'none';
 }
 let btnShow = document.getElementById("btn-show");
 let btnHide = document.getElementById("btn-hide");
 
 btnHide.addEventListener('click', hideImage);
 btnShow.addEventListener('click', showImage);